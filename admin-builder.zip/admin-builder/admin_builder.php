<?php
/*
  Plugin Name: Admin Builder
  Plugin URI: http://rootabout.com/admin-builder
  Description: A plugin that generates admin panel pages & posts, meta boxes and fields (with unlimited textbox, textarea, checkbox, custom select (dropdown box), datepicker, timepicker, colorpicker, upload media fields, with configurable options)
  Version: 1.0
  Author: rootabout
  Author URI: http://rootabout.com
  License: GPLv2 or later
  Text Domain: aB
 */
 require_once('inc/enqueue.php');
 require_once('inc/core.php');
