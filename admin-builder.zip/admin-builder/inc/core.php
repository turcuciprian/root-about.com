<?php
// generating the fields
require_once 'fields.php';
// generating meta boxes
include 'meta.php';
// general functionality
include 'general.php';

//
//
// Initializing the functionality
//
//

//initialize the class
if (is_admin()) {
    //
    global $metaboxesArr;
    //General Functionality
    $aBGeneral = new GeneralFunctionality();
    //load saved settings from the database ON LOAD
$aBGeneral->initialize_menu();
    $dataArr = $aBGeneral->loadDB();

    // $aBGeneral->showArr($dataArr);
    // meta boxes functionality
    new aBMetaClass($dataArr);
}
