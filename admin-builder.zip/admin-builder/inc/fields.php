<?php
class fieldsC
{
    // add simple textbox field
    public function addMeta_field($args)
    {
        $field = $args[0] ? $args[0] : '';
        $metaboxName = $args[1]['name'] ? $args[1]['name'] : '';
        $post = $args[2] ? $args[2] : '';
        $type = $field['type'] ? $field['type'] : null;
        if (isset($field['post_status'])) {
            $post_status = $field['post_status'] ? $field['post_status'] : '';
        } else {
            $post_status = '';
        }
        $fieldName = esc_attr('aBMB_'.$metaboxName.$field['name']);
        $fieldValue = get_post_meta($post->ID, $fieldName, true);
        $label = $field['label'];
        $description = $field['description'];
        $fieldHTML = '';
        switch ($type) {
        case 'textbox':
        $fieldHTML = '<input class="widefat" type="text" name="'.$fieldName.'"  id="'.$fieldName.'" value="'.$fieldValue.'" size="30" />';
        break;
        case 'textarea':
        $fieldHTML = '<textarea name="'.$fieldName.'" id="'.$fieldName.'" class="widefat" rows="8" cols="40">'.$fieldValue.'</textarea>';
        break;
        case 'checkbox':
        $extraText = $field['extraText'] ? $field['extraText'] : '';
        $fieldHTML = '<input type="checkbox" name="'.$fieldName.'"  id="'.$fieldName.'" '.checked('on', $fieldValue, false).' size="30" /> <span class="extraText">'.$extraText.'</span>';
        break;
        case 'select':
        $customList = $field['oArr'] ? $field['oArr'] : array('label' => '0', 'value' => 'Empty');
        //lines into array
        $fieldHTML = '<select name="'.$fieldName.'" id="'.$fieldName.'">';
        switch ($field['selectType']) {
          case 'custom':
          foreach ($customList as $key => $option) {
              //comma separated string into array
            $selected = selected($option->value, $fieldValue, false) ? selected($option->value, $fieldValue, false) : '';
            //set the options
            $fieldHTML .= '<option  '.$selected.' value="'.$option->value.'" >'.$option->label.'</option>';
          }
          break;
          case 'categories':
          $customList = get_categories(
                                      array(
                                          'orderby' => 'name',
                                          'order' => 'ASC',
                                          'hide_empty' => 0,
                                      )
                                    );

          //lines into array
          foreach ($customList as $option) {
              //comma separated string into array
            $selected = selected($option->slug, $fieldValue, false) ? selected($option->slug, $fieldValue, false) : '';
            //set the options
            $fieldHTML .= '<option  '.$selected.' value="'.$option->slug.'" >'.$option->name.'</option>';
          }
          break;
          case 'tags':
          $customList = get_tags(
                                  array(
                                      'orderby' => 'name',
                                      'order' => 'ASC',
                                      'hide_empty' => 0,
                                  )
                                );

          //lines into array
          foreach ($customList as $option) {
              //comma separated string into array
            $selected = selected($option->slug, $fieldValue, false) ? selected($option->slug, $fieldValue, false) : '';
            //set the options
            $fieldHTML .= '<option  '.$selected.' value="'.$option->slug.'" >'.$option->name.'</option>';
          }
          break;
          case 'pages':
          $customList = get_posts(
                                  array(
                                      'orderby' => 'name',
                                      'order' => 'ASC',
                                      'hide_empty' => 0,
                                      'post_type' => 'page',
                                      'post_status' => $post_status,
                                  )
                                );

          //lines into array
          foreach ($customList as $page) {
              //comma separated string into array
          $selected = selected($page->ID, $fieldValue, false) ? selected($page->ID, $fieldValue, false) : '';
          //set the options
          $fieldHTML .= '<option  '.$selected.' value="'.$page->ID.'" >'.$page->post_title.'</option>';
          }
          $fieldHTML .= '</select>';

          break;
          case 'posts':
          $customList = get_posts(
                                  array(
                                      'orderby' => 'name',
                                      'order' => 'ASC',
                                      'hide_empty' => 0,
                                      'post_type' => 'post',
                                      'post_status' => $post_status,
                                  )
                                );
          //lines into array
          foreach ($customList as $post) {
              //comma separated string into array
            $selected = selected($post->ID, $fieldValue, false) ? selected($post->ID, $fieldValue, false) : '';
            //set the options
            $fieldHTML .= '<option  '.$selected.' value="'.$post->ID.'" >'.$post->post_title.'</option>';
          }

          break;
        }
        //
        //END of select types switch
        //
        $fieldHTML .= '</select>';
        break;
        case 'datepicker':
        $fieldHTML = '<input class="aBDatepicker" type="text" data-dateformat="'.$field['format'].'" name="'.$fieldName.'"  id="'.$fieldName.'" value="'.$fieldValue.'" readonly size="20" />';
        break;
        case 'timepicker':
        $fieldHTML = '<input class="aBTimepicker" type="text" name="'.$fieldName.'" id="'.$fieldName.'" value="'.$fieldValue.'" size="10" />';
        break;
        case 'colorpicker':
        $fieldHTML = '<input class=" aBColorpicker" readonly type="text" name="'.$fieldName.'"  id="'.$fieldName.'" value="'.$fieldValue.'" size="10" />';
        break;
        case 'radio':
        // var_dump($field);
        // exit;
        if(isset($field['radioType']) && $field['radioType']==='custom'){
          $fieldHTML ='';
          foreach ($field['oArr'] as $radio) {
            $tempChecked = checked($radio->value,$fieldValue, false);
            $checked = $tempChecked ? $tempChecked : '';

            $fieldHTML .='<input type="radio" name="'.$fieldName.'" '.$checked.' value="'.$radio->value.'"> '.$radio->label.' ';
            if($field['orientation']==='v'){
              //add new line if orientation is set to vertical
              $fieldHTML.="<br/>";
            }
          }
        }
        break;
        case 'upload':
        $buttonString = 'Upload';
        if(!empty($fieldValue)){
          $buttonString = 'Remove';

        }
        $fieldHTML .='<button class="aBUpload">'.$buttonString.'</button><br/><br/>';
        $fieldHTML .='<input type="hidden" name="'.$fieldName.'" value="'.$fieldValue.'" />';
        $fieldHTML .='<img src="'.$fieldValue.'" alt="Uploaded image for '.$field['label'].'" class="uploadImage" width="100" height="100" />';
        break;
      }
        ?>
      <div class="row field">
        <div class="col-sm-2">
          <label class="title"><?php _e($label);
        ?></label>
        </div>
        <div class="col-sm-10">
          <?php echo $fieldHTML;
        ?>
          <label class="description">* <?php _e($description);
        ?></label>
        </div>
      </div>
      <?php

    }
}
