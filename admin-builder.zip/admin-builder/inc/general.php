<?php
class GeneralFunctionality
{
    public function initialize_menu(){
      // Hook for adding admin menus
      add_action('admin_menu', array($this, 'mt_add_pages'));
    }

    // action function for above hook
    public function mt_add_pages()
    {
        add_menu_page(__('Test Toplevel', 'menu-test'), __('Admin Builder', 'abSettings'), 'manage_options', 'abSettings', array($this, 'abSettingsCallback'));
    }

    // mt_settings_page() displays the page content for the Test settings submenu
    public function abSettingsCallback()
    {
        $url = plugins_url();
        require_once plugin_dir_path(__FILE__).'main.php';
    }
    public function loadDB()
    {
        $data = get_option('aBData');
        $data = stripslashes($data);
        $data = json_decode($data);

        return $data;
    }
    // print an array properly
    public function showArr($arr, $exit = true)
    {
        echo '<pre>';
        print_r($arr);
        echo '</pre>';
        if ($exit) {
            exit;
        }
    }
}
